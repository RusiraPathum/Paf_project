-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2021 at 05:13 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gadgetbadget`
--

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE `ordertable` (
  `orderID` int(11) NOT NULL,
  `orderCode` varchar(15) NOT NULL,
  `orderType` varchar(50) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `customerContact` varchar(50) NOT NULL,
  `totalAmount` double(20,3) NOT NULL,
  `cardNo` int(11) NOT NULL,
  `cvvNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`orderID`, `orderCode`, `orderType`, `customerName`, `customerContact`, `totalAmount`, `cardNo`, `cvvNo`) VALUES
(1001, '100', 'zip', 'janaka', '714563242', 50000.000, 444444, 678),
(1002, '101', 'zip', 'anuka', '776675444', 30000.000, 111111, 123),
(1003, '102', 'zip', 'asanath', '776554778', 40000.000, 222222, 999),
(1004, '103', 'Zip', 'suranga', '751119812', 1500.000, 777777, 432),
(1005, '104', 'Zip', 'suranga', '751119812', 1500.000, 777777, 432),
(1006, '105', 'Zip', 'jeewa', '784147721', 18000.000, 555555, 771),
(1007, '106', 'Zip', 'prasad', '774551472', 18000.000, 666666, 885);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ordertable`
--
ALTER TABLE `ordertable`
  ADD PRIMARY KEY (`orderID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ordertable`
--
ALTER TABLE `ordertable`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1008;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
